<?php 

if (isset($_POST['submit'])) {
    $name = $_POST['name'];
    $emailFrom = $_POST['email'];
    $message = $_POST['message'];

    $mailTo = "cjroberts2013@gmail.com"
    $subject = "Freelance Portfolio inquiry"
    $headers = "From: ".$mailTo;
    $txt = "You have recieved an email from ".$name.".\n\n".$message;

    mail($mailTo, $subject, $txt, $headers);
    header("Location: index.html?mailsend")
}